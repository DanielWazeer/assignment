﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Part2
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
        }
        Form1 form1 = new Form1();
        private void btn_register_Click(object sender, EventArgs e)
        {
            registerPair();
        }
        void registerPair()
        {
            bool search = false;
            foreach (KeyValuePair<string, string> pair in Form1.dict)
            {
                if (pair.Key == tb_username.Text)
                {
                    search = true;
                    MessageBox.Show("User already exists.");
                    form1.Show();
                    this.Close();
                }
            }
            if (search == false)
            {
                Form1.dict.Add(tb_username.Text, tb_password.Text);
                MessageBox.Show("User added.");
                form1.Show();
                this.Close();
            }
        }
    }
}
