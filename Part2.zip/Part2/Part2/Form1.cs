﻿using System;
using System.Collections.Generic;

using System.Windows.Forms;

namespace Part2
{
    public partial class Form1 : Form
    {
        public static Dictionary<string, string> dict = new Dictionary<string, string>();
        public Form1()
        {
            InitializeComponent();
        }


        private void btn_login_Click(object sender, EventArgs e)
        {
            login(ref dict);
        }

        public void login(ref Dictionary<string, string> dict)
        {
            bool found = false;
            foreach (KeyValuePair<string, string> pair in dict)
            {
                if (pair.Key == tb_username.Text && pair.Value == tb_password.Text)
                {
                    found = true;
                    Form2 form2 = new Form2();
                    this.Hide();
                    form2.Show();
                }
            }
            if(!found)
                MessageBox.Show("User not found.");
        }


        private void btn_register_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
